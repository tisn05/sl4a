import android
droid = android.Android()
droid.makeToast('Hello, Android!')
print 'Hello world!'
